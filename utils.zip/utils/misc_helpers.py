import time


def get_time():
    return int(time.time())
